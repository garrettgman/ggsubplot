# 0-Introduction
library(ggplot2)

# Review
qplot(displ, hwy, data = mpg)
qplot(displ, hwy, data = mpg, color = class)
qplot(cty, hwy, data = mpg, geom = "jitter")
qplot(hwy, data = mpg, binwidth = 1)

p <- qplot(displ, hwy, data = mpg) 
p + facet_grid(. ~ cyl)
p + facet_grid(drv ~ .)
p + facet_grid(drv ~ cyl)
p + facet_wrap(~ class)

qplot(class, hwy, data = mpg, geom = c("jitter", "boxplot"))
qplot(class, hwy, data = mpg, geom = "jitter") + geom_boxplot()

qplot(hwy, cty, data = mpg, color = "blue")
qplot(hwy, cty, data = mpg, color = I("blue"))