# 01-grammar
library(ggplot2)
library(hexbin)
library(ggmap)

# Your turn
qplot(date, unemploy, data = economics, geom = "line")
qplot(class, hwy, data = mpg, geom = "jitter", color = class)

# stats
ggplot(mpg, aes(hwy)) + geom_histogram(binwidth = 1)
ggplot(diamonds, aes(carat, price)) + geom_point()
ggplot(diamonds, aes(carat, price)) + geom_bin2d()
ggsave("images/diamond-bin2d.pdf", width = 6, height = 4.5)
ggplot(diamonds, aes(carat, price)) + geom_hex(aes(fill = sqrt(..count..)))

# from http://is-r.tumblr.com/post/36204333530/representing-density-in-two-dimensions
myData <- data.frame(X = rnorm(nObs), Y = rnorm(nObs))
nClusters <- 7  # Cluster it
kMeans <- kmeans(myData, centers = nClusters)
myData$Cluster <- as.factor(kMeans$cluster)
ggplot(myData, aes(x = X, y = Y)) +
  stat_density2d(aes(fill = Cluster, colour = Cluster, alpha = ..level.., 
                     size = ..level..), geom = "polygon") + 
  scale_alpha("density", range = c(0, 1/2)) + 
  scale_size(range = c(0, 3/2), guide = "none")

# position
qplot(color, data = diamonds, fill = cut, position = "dodge")
qplot(color, data = diamonds, fill = cut, position = "stack")
qplot(color, data = diamonds, fill = cut, position = "dodge")
qplot(color, data = diamonds, fill = cut, position = "identity")
qplot(color, data = diamonds, fill = cut, position = "fill")

# layers
layer(data, mapping, geom, stat, position, ...)

layer(
  data = mpg, 
  mapping = aes(x = displ, y = hwy),
  geom = "point", 
  stat = "identity", 
  position = "identity"
)

layer(
  data = diamonds,
  mapping = aes(x = carat),
  geom = "bar",
  stat = "bin",
  position = "stack"# To actually create the plot
  ggplot() + 
    geom_point(aes(displ, hwy), data = mpg)
  
  ggplot() + 
    geom_histogram(aes(carat), data = diamonds)
)

# A lot of typing!  

layer(
  data = mpg, 
  mapping = aes(x = displ, y = hwy),
  geom = "point", 
  stat = "identity", 
  position = "identity"
)

# Every geom has an associated default statistic
# (and vice versa), and position adjustment.

geom_point(aes(displ, hwy), data = mpg)
geom_histogram(aes(carat), data = diamonds)

# To actually create the plot
ggplot() + 
  geom_point(aes(displ, hwy), data = mpg)

ggplot() + 
  geom_histogram(aes(carat), data = diamonds)

# Multiple layers
ggplot() + 
  geom_point(data = mpg, aes(displ, hwy)) + 
  geom_smooth(data = mpg, aes(displ, hwy))

# Avoid redundancy:
ggplot(aes(displ, hwy), data = mpg) + 
  geom_point() + 
  geom_smooth()

# Different layers can have different aesthetics
ggplot(mpg, aes(displ, hwy)) + 
  geom_smooth() +
  geom_point(aes(colour = class))

ggplot(mpg, aes(displ, hwy, colour = class)) + 
  geom_point() + 
  geom_smooth(method = "lm", se = F)

ggplot(mpg, aes(displ, hwy)) + 
  geom_point(aes(colour = class)) + 
  geom_smooth(aes(group = class), method = "lm", se = F)

ggplot(mpg, aes(displ, hwy)) + 
  geom_point(aes(colour = class)) + 
  geom_smooth(aes(group = class), method = "lm", se = F,
              colour = "black")

ggplot(mpg, aes(displ, hwy)) + 
  geom_smooth(aes(group = class), method = "lm", se = F,
              colour = "black") +
  geom_point(aes(colour = class))

# ggplot doesn't stop you from doing dumb things

ggplot(mpg, aes(displ, hwy)) + 
  geom_point() +
  geom_point(aes(cyl, displ))

ggplot(mpg, aes(displ, hwy)) + 
  geom_point() +
  geom_point(aes(y = cty), colour = "red")

ggplot(mpg, aes(displ, hwy)) + 
  geom_point() +
  geom_point(aes(y = cty), colour = "red") + 
  geom_segment(aes(xend = displ, y = cty, yend = hwy))

# Your turn
qplot(carat, price, data = diamonds)
qplot(hwy, cty, data = mpg, geom = "jitter")
qplot(reorder(class, hwy), hwy, data = mpg, geom = c("jitter", "boxplot"))
qplot(log10(carat), log10(price), data = diamonds, colour = color) + 
  geom_smooth(method = "lm")

ggplot(diamonds, aes(carat, price)) + 
  geom_point()

ggplot(mpg, aes(hwy, cty)) + 
  geom_jitter()

ggplot(mpg, aes(reorder(class, hwy), hwy)) + 
  geom_jitter() + 
  geom_boxplot()
ggplot(diamonds, aes(log10(carat), log10(price),  
                     colour = color)) + 
  geom_point() + 
  geom_smooth(method = "lm")


# Minard's March

troops <- read.table("code-and-data/minard-troops.txt", header=T)
cities <- read.table("code-and-data/minard-cities.txt", header=T)

march <- geom_path(aes(long, lat, size = survivors, color = direction, 
                       group = group), lineend = "round", data = troops)
cities <- geom_text(aes(label = city), size = 4, data = cities)

sf <- geocode("San Francisco")
sf_map <- get_map(unlist(sf), source = "google", zoom = 12)
ggmap(sf_map)

geocode("fisherman's wharf")
revgeocode(c(lon = -122.4086, 37.78774))

russia <- get_map(c(lon = 28.3, lat = 54.9), source = "google", zoom = 5)
russia2 <- get_map(c(20, 53, 40, 60), source = "osm") #slower

ggmap(russia) + troops + coord_map()
ggmap(russia2) + troops + coord_map()