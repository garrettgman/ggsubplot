library(ggplot2)
library(scales)
library(maps)
library(RColorBrewer)

borders <- read.csv("code-and-data/texas.csv")
texas <- ggplot(borders, aes(long, lat))
texas + geom_point()
texas + geom_line()
texas + geom_path()
texas + geom_path(aes(group = group))
texas + geom_polygon(aes(group = group))
texas + geom_polygon(aes(group = group), colour = "grey50", fill = NA)
borders2 <- borders[sample(nrow(borders)), ]  
ggplot(borders2, aes(long, lat)) + geom_polygon(aes(group = group))
texas + geom_polygon(aes(group = group)) +     
  coord_map("lambert", lat0 = 27.416667, lat1 = 34.916667)

# install.packages("maps")

library(maps)
states <- map_data("state")

ggplot(states, aes(long, lat)) + 
  geom_polygon(aes(group = group, fill = group))

help(package = "maps")

# Your turn - California's counties
counties <- map_data("county")
california <- counties[counties$region == "california", ]

ggplot(california, aes(long, lat)) + 
  geom_polygon(aes(group = group, fill = group))

tx <- texas + 
  geom_polygon(aes(group = group, 
                   fill = bin))

tx



p <- qplot(displ, hwy, data = mpg, color = cty)

# First argument (name) controls axis label
p + scale_y_continuous("Miles per Gallon (Highway)")
p + scale_x_continuous("Displacement (l)")

# Breaks and labels control tick marks
p + scale_x_continuous(breaks = NULL)
p + scale_x_continuous(breaks = c(2, 4.5, 7),
                       labels = c("small", "medium", "big"))

# Limits control range of data
p + scale_y_continuous(limits = c(20, 40))
# same as:
p + ylim(20, 40)

# Basically the same for discrete variables
q <- qplot(color, carat, data = diamonds, geom = "jitter", color = color)

# breaks controls which are labeled
q + scale_x_discrete(breaks = c("D", "E", "F"))

# for non x,y aesthetics, scales affect legend
q + scale_color_discrete(labels = c(1:7))

# limits controls which are displayed
q + scale_x_discrete(limits = c("D", "E", "F"))

# Works for other geoms
ggplot(diamonds, aes(x = color, y = carat)) + 
  geom_violin() + 
  scale_x_discrete(limits = c("D", "E", "F"))

## Your turn
tx + scale_fill_discrete("Population", 
  labels = c("0 - 999", "1,000 - 9,999", 
  "10,000 - 99,999", "100,000 - 999,999", 
  "1,000,000+")) +
  scale_x_continuous("") + 
  scale_y_continuous("")


tx
tx + scale_fill_grey()


r <- qplot(displ, cty, colour = drv, shape = fl, data = mpg) 

# Specify the shapes manually
r + scale_shape_manual(values = c(0, 15, 1, 16, 3))

# Specify colors manually
r + scale_colour_manual(values = c("red", "black", "#3333cc"))

?pch

# Scales and perception
RColorBrewer::display.brewer.all()
q + scale_color_brewer(palette="Spectral")
q + scale_color_brewer(palette="Set3")
show_col(brewer_pal(palette = "YlOrRd")(9))
q + scale_color_grey()

# Your turn
tx + scale_fill_brewer("Population", 
                       palette = "Blues",
                       labels = c("0 - 999", "1,000 - 9,999", 
                                  "10,000 - 99,999", "100,000 - 999,999", 
                                  "1,000,000+")) +
  scale_x_continuous("") + 
  scale_y_continuous("")

# Continuous scales
p + scale_color_gradientn(colours= c("red", "green", "blue"))
# note that british spelling of colour matters :P
p + scale_color_gradientn(colors= c("red", "green", "blue"))

Creates a function that returns n ordered values from a brewer palette.
# a function
brewer_pal(palette = "YlOrRd")
# a vector
brewer_pal(palette = "YlOrRd")(6)

show_col(brewer_pal(palette = "YlOrRd")(6))
# some default palettes
show_col(brewer_pal(type = "seq")(6))
show_col(brewer_pal(type = "div")(6))
show_col(brewer_pal(type = "qual")(6))

# muted
show_col(c("red", "blue", muted("red"),  
           muted("blue")))

texas + 
  geom_polygon(aes(group = group, 
                   fill = log(pop)))


deaths <- read.csv("code-and-data/mortality08.csv.bz2", stringsAsFactors = FALSE)
head(deaths)

mexico <- ggplot(deaths, aes(long, lat)) +
  geom_point()

mexico <- ggplot(deaths, aes(long, lat, size = freq)) + geom_point()
mexico
mexico + scale_area()
mexico + scale_area(range = c(0.1, 5))

