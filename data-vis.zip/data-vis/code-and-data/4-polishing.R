# 4-polishing

library(ggplot2)
library(scales)
library(ReadImages)

# What are guides?
diamonds2 <- ddply(diamonds, c("color", "cut"), summarise, avg.price = mean(price))
qplot(cut, avg.price, data = diamonds2, geom = "bar", fill = color, 
      position = "dodge") + guides(fill = "none")
qplot(cut, avg.price, data = diamonds2, geom = "bar", fill = color, 
      position = "dodge")

# colorbar vs. legend

# three main types of guides
q <- qplot(displ, hwy, data = mpg, color = cty)

#  colorbars
q + guides(color = "colorbar")
# legends
q + guides(color = "legend")
q + guides(color = "none")

p <- qplot(color, data = diamonds, fill = clarity)
p

# guides can be highly cutomized
p + guides(fill = guide_legend("Sparkliness"))
p + guides(fill = guide_legend(nrow = 4, title.hjust = 0.5))
p + guides(fill = guide_legend(direction = "horizontal", 
      title.position = "top", label.position = "bottom"))

# colorbar barwidth, barheight, ticks
q + guides(color = guide_colorbar(barwidth = 0.5))
q + guides(color = guide_colorbar(barheight = 18))
q + guides(color = guide_colorbar(ticks = FALSE, barwidth = 2))

# Your turn
texas + 
  geom_polygon(aes(group = group, 
                   fill = log(pop)))

# what went wrong?
qplot(carat, price, data = diamonds, color = color, alpha = I(0.05))

qplot(carat, price, data = diamonds, color = color, alpha = I(0.05)) + 
  guides(color = guide_legend(override.aes =list(alpha = 1)))

# titles
q + ggtitle("Big engines get lower mileage")

# Add a single text object
q + annotate("text", x = 6.5, y = 28, 
             label = "Sports cars", colour = "blue", 
             size = 6)

# Add a single rectangle
q + annotate("rect", xmin = 5.5, xmax = 7.1,
             ymin = 22, ymax = 27, fill = "blue",
             colour = "black", alpha = 0.2)

# Lines are different
# (this will change in next version)
q + geom_vline(xintercept = 6, colour = "blue",
               linetype="dashed")

# annotate_raster
rstudio <- read.jpeg("images/rstudio.jpg")
q + annotation_raster(rstudio, xmin = 1.5, xmax = 3, ymin = 12, ymax = 15)

inset <- ggplotGrob(qplot(color, data = diamonds, fill = clarity, position = "fill") + guides(fill = "none"))
p + annotation_custom(inset, xmin = 5.6, xmax = 7.5, ymin = 7500, ymax = 11000)

# Your turn
states <- map_data("state")
states$texas <- states$region == "texas"
inset <- ggplot(states, aes(long, lat, group = group)) +
  geom_polygon(aes(fill = texas), color = "grey50") +
  scale_x_continuous("", breaks = c()) +
  scale_y_continuous("", breaks = c()) +
  scale_fill_manual(values = c("white", "black")) +
  guides(fill = "none")
inset <- ggplotGrob(inset)

tx + scale_fill_brewer("Population", 
                       palette = "Blues",
                       labels = c("0 - 999", "1,000 - 9,999", 
                                  "10,000 - 99,999", "100,000 - 999,999", 
                                  "1,000,000+")) +
  scale_x_continuous("") + 
  scale_y_continuous("") + 
  annotation_custom(inset, xmin = -108, xmax = -101, ymin = 24.7, ymax = 28.5) 

tx + scale_fill_brewer("Population", 
                       palette = "Blues",
                       labels = c("0 - 999", "1,000 - 9,999", 
                                  "10,000 - 99,999", "100,000 - 999,999", 
                                  "1,000,000+")) +
  scale_x_continuous("") + 
  scale_y_continuous("") + borders("state", region = "texas", colour = "grey20")


# Coordinate Systems
p <- ggplot(pressure, aes(x=temperature, y=pressure)) +
  geom_point(size = 4) + geom_line(linetype = "dashed")
p

# Zooming
# plots the graph then zooms
p + coord_cartesian(ylim = c(-10, 150))
# Contrast with setting scale limits
# subsets the data, then plots
p + scale_y_continuous(limits = c(-10, 150))
p + ylim(c(-10, 150))


# Fixed aspect ratio
p + coord_fixed()
p + coord_fixed(ratio = 1/3)

# Swap x and y axes
p + coord_flip()

# Quick transforms
p <- qplot(carat, price, data = diamonds)

# Transform data
qplot(log(carat), log(price), 
      data = diamonds)

# Transform scale
p + scale_y_log10() + scale_x_log10()

# Transform coordinates
p + coord_trans(x = "log10", y = "log10")

# polar coordinates
# what is a barchart in polar coordinates?
ggplot(diamonds, aes(factor(1), fill = color)) + geom_bar(width = 1)
# a pie graph
ggplot(diamonds, aes(factor(1), fill = color)) + geom_bar(width = 1) + 
  coord_polar(theta = "y")
ggplot(diamonds, aes(factor(1), fill = color)) + geom_bar(width = 1) + 
  coord_polar()


# Your turn
tx + scale_fill_brewer("Population", 
                       palette = "Blues",
                       labels = c("0 - 999", "1,000 - 9,999", 
                                  "10,000 - 99,999", "100,000 - 999,999", 
                                  "1,000,000+")) +
  scale_x_continuous("") + 
  scale_y_continuous("") +
  coord_map("azequalarea")

# Themes

qplot(displ, cty, data = mpg) + theme_grey() # Default
qplot(displ, cty, data = mpg) + theme_bw()

# Use theme_set if you want it to apply to every
# future plot in current the R session
theme_set(theme_bw())

theme_grey() 
theme_bw()

q + theme(legend.position = "bottom")
q + theme(panel.border = element_rect(colour = "black", fill = NA))

element_rect()
element_rect(colour = "black", fill = NA)

# Examples from theme_grey(base_family, base_size)

plot.title = element_text(family = base_family,
                          size = base_size * 1.2)

# Tick mark labels
axis.text.x = element_text(family = base_family, 
                           size = base_size * 0.8, lineheight = 0.9,
                           colour = "grey50", vjust = 1)

# Axis title
axis.title.y = element_text(family = base_family, 
                            size = base_size, angle = 90, vjust = 0.5)

# Grid lines
panel.grid.major = element_line(colour = "white")
panel.grid.minor = element_line(colour = "grey95", size = 0.25)

# Facet labels
strip.text.y = element_text(family = base_family,
                            size = base_size * 0.8, angle = -90),

# Your turn
tx + scale_fill_brewer("Population", 
                       palette = "Blues",
                       labels = c("0 - 999", "1,000 - 9,999", 
                                  "10,000 - 99,999", "100,000 - 999,999", 
                                  "1,000,000+")) +
  scale_x_continuous("") + 
  scale_y_continuous("") +
  coord_map() +
  theme_bw() +
  theme(axis.ticks = element_blank(),
        axis.text = element_blank()) +
  ggtitle("Population of Texas Counties")


# ggthemes
library(dev_tools)
install_github("ggthemes", "jrnold")

p <- qplot(color, data = diamonds, fill = cut, position = "dodge")
p
p + theme_excel2003() + scale_fill_excel2003()
p + theme_excel2003()
p + theme_economist() + scale_fill_economist()
p + theme_few() + scale_fill_few()
p + theme_solarized() + scale_fill_solarized()
p + theme_stata() + scale_fill_stata()
p + theme_tufte() + scale_fill_excel10()
p + theme_wsj() + scale_fill_wsj(palette = "black_green")

library(extrafont)
loadfonts()

p + scale_fill_grey() +
  ggtitle("Made with extrafont") +
  theme(text = element_text(size=16,  
                            family = "Orbitron", 
                            colour = "red"))

ggsave("images/fonttest-orbitron.pdf")
embed_fonts("images/fonttest-orbitron.pdf")

ggpairs(tips)
ggsave("images/ggpairs.pdf", width = 16, height = 12)